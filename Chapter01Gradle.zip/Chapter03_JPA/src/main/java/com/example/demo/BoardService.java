package com.example.demo;

import java.util.List;

public interface BoardService {

	public void write();

	public List<BoardDTO> getBoardList();

}
