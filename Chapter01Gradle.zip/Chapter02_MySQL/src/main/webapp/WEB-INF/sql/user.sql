create table USER_IMAGE_BOARD (
    SEQ number PRIMARY key,
    IMAGE_NAME  varchar2(50) not NULL, 
    IMAGE_CONTENT varchar2(4000) null,
    IMAGE1 VARCHAR2(200) not null
);