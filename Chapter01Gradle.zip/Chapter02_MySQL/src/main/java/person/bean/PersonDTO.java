package person.bean;

import lombok.Getter; import lombok.Setter;

@Getter
@Setter 
public class PersonDTO { 
	private int seq; 
	private String name; 
	private int age;
	private String photo;

}
