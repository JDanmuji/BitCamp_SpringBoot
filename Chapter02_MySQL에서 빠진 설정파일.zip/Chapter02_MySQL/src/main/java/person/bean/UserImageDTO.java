/*
 * package user.bean;
 * 
 * import org.springframework.stereotype.Component;
 * 
 * import lombok.Getter; import lombok.Setter;
 * 
 * @Component
 * 
 * @Setter
 * 
 * @Getter public class UserImageDTO { private int seq; private String
 * imageName; private String imageContent; private String image1;
 * 
 * 
 * }
 */